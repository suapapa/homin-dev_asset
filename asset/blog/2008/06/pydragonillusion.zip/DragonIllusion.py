#!/usr/bin/env python
# -*- coding: utf-8 -*-

# DragonIllusion.py:
#     Simulate paper folding Dragon illusion.
#       (from http://www.grand-illusions.com/opticalillusions/dragon_illusion/)
#     code base on bmpTextur.cpp by hihimani
#       (from http://blog.naver.com/hihimani/80044960403)

# Copyright (c) 2008 Homin Lee <ff4500@gmail.com>

# This program is free software: you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation, either version 3 of the License, or
# (at your option) any later version.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this program.  If not, see <http://www.gnu.org/licenses/>.
import wx
import sys
import math

from Image import open

try:
    from wx import glcanvas
    haveGLCanvas = True
except ImportError:
    haveGLCanvas = False

try:
    from OpenGL.GL import *
    from OpenGL.GLUT import *
    haveOpenGL = True
except ImportError:
    haveOpenGL = False

class DICanvas(glcanvas.GLCanvas):
    def __init__(self, parent):
        glcanvas.GLCanvas.__init__(self, parent, -1)
        self.init = False
	self.dx = 0
	self.dy = 0
	self.xAngle = 0
	self.yAngle = 0
        self.size = None
        self.Bind(wx.EVT_ERASE_BACKGROUND, self.OnEraseBackground)
        self.Bind(wx.EVT_SIZE, self.OnSize)
        self.Bind(wx.EVT_PAINT, self.OnPaint)
        self.Bind(wx.EVT_LEFT_DOWN, self.OnMouseDown)
        self.Bind(wx.EVT_LEFT_UP, self.OnMouseUp)
        self.Bind(wx.EVT_MOTION, self.OnMouseMotion)

        self._texMap_Dragon = (\
            (((188, 183), (0, 0, 0)), ((293, 202), (105, 21, 0)), ((286, 130), (98, -51, 0)), ((205, 135), (13, -42, 0))),
            (((188, 183), (0, 0, 0)), ((293, 202), (105, 21, 0)), ((227, 262), (39, 81, 0)), ((188, 183), (0, 0, 0))),
            (((188, 183), (0, 0, 0)), ((227, 262), (39, 81, 0)), ((108, 257), (-80, 76, 0)), ((100, 215), (-88, 25, 0))),
            (((358, 467), (170, 286, 0)), ((155, 457), (-33, 276, 0)), ((227, 262), (39, 81, 0)), ((293, 202), (105, 21, 0))),
            (((293, 202), (105, 21, 0)), ((432, 268), (140, 150, -175)), ((505, 378), (170, 286, -175)), ((358, 467), (170, 286, 0))),
            (((108, 257), (50, 150, -120)), ((155, 457), (-33, 276, 0)), ((227, 262), (39, 81, 0)), ((108, 257), (50, 150, -120))),
            (((15, 355), (0, 286, -175)), ((155, 457), (-33, 276, 0)), ((108, 257), (50, 150, -120)), ((51, 302), (50, 219, -175))),
            (((145, 48), (0, 0, 94)), ((152, 138), (0, 0, 0)), ((205, 135), (13, -42, 0)), ((195, 45), (13, -42, 93))),
            (((53, 57), (-88, 25, 93)), ((56, 152), (-88, 25, 0)), ((152, 138), (0, 0, 0)), ((145, 48), (0, 0, 93))),
            (((2, 63), (-80, 76, 93)), ((5, 156), (-80, 76, 0)), ((56, 152), (-88, 25, 0)), ((53, 57), (-88, 25, 93))),
            (((195, 45), (13, -42, 93)), ((205, 135), (13, -42, 0)), ((286, 130), (98, -51, 0)), ((263, 34), (98, -51, 93))),
            (((263, 34), (98, -51, 93)), ((286, 130), (98, -51, 0)), ((346, 103), (98, -116, 0)), ((315, 13), (98, -116, 93))),
        )

    def OnEraseBackground(self, event):
        pass # Do nothing, to avoid flashing on MSW.

    def OnSize(self, event):
        size = self.size = self.GetClientSize()
        if self.GetContext():
            self.SetCurrent()
            glViewport(0, 0, size.width, size.height)
        event.Skip()

    def OnPaint(self, event):
        dc = wx.PaintDC(self)
        self.SetCurrent()
        if not self.init:
            self.InitGL()
            self.init = True
        self.OnDraw()

    def InitGL(self):
        # set viewing projection
        glMatrixMode(GL_PROJECTION)
        glFrustum(-0.5, 0.5, -0.5, 0.5, 1.0, 3.0)

        # position viewer
        glMatrixMode(GL_MODELVIEW)
        glTranslatef(0.0, 0.0, -2.0)

        # position object
        #glRotatef(self.y, 1.0, 0.0, 0.0)
        #glRotatef(self.x, 0.0, 1.0, 0.0)

	glScalef(0.3, 0.3, 0.3)

        glEnable(GL_DEPTH_TEST)
        glEnable(GL_LIGHTING)
        glEnable(GL_LIGHT0)
        self._texID_Dragon = self.loadImage("sauce.bmp")

        glEnable(GL_TEXTURE_2D)
        glTexParameterf(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_NEAREST)
        glTexParameterf(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_NEAREST)
        glTexEnvf(GL_TEXTURE_ENV, GL_TEXTURE_ENV_MODE, GL_DECAL)


    def OnDraw(self):
        # clear color and depth buffers
        glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT)

        glBindTexture(GL_TEXTURE_2D, self._texID_Dragon)

        # draw the Dragon
        glBegin(GL_QUADS)
        for texMap in self._texMap_Dragon:
            for t, v in texMap:
                x, y = t
                glTexCoord2f(x / 512.0, (512 - y) / 512.0)
                x, y, z = v
                glVertex3f(-1 + x / 100.0, 1.8 - y / 100.0, 0 + z / 100.0);
        glEnd()

        if self.size is None:
            self.size = self.GetClientSize()
        w, h = self.size
        w = max(w, 1.0)
        h = max(h, 1.0)
        xScale = 180.0 / w
        yScale = 180.0 / h
        glRotatef((self.yAngle) * yScale, 1.0, 0.0, 0.0);
        glRotatef((self.xAngle) * xScale, 0.0, 1.0, 0.0);

        self.SwapBuffers()

    def OnMouseDown(self, evt):
        self.CaptureMouse()
        self.lastx, self.lasty = evt.GetPosition()

    def OnMouseUp(self, evt):
        self.ReleaseMouse()

    def OnMouseMotion(self, evt):
        if evt.Dragging() and evt.LeftIsDown():
            x, y = evt.GetPosition()
	    self.xAngle = (self.lastx - x) * 0.5
	    self.yAngle = (self.lasty - y) * 0.5
	    self.lastx, self.lasty = x, y
	    self.dx, self.dy = x, y
            self.Refresh(False)

    def loadImage( self, imageName):
        im = open(imageName)
        try:
            ix, iy, image = im.size[0], im.size[1], im.tostring("raw", "RGBA", 0, -1)
        except SystemError:
            ix, iy, image = im.size[0], im.size[1], im.tostring("raw", "RGBX", 0, -1)
        # generate a texture ID
        ID = glGenTextures(1)
        # make it current
        glBindTexture(GL_TEXTURE_2D, ID)
        glPixelStorei(GL_UNPACK_ALIGNMENT,1)
        # copy the texture into the current texture ID
        glTexImage2D(GL_TEXTURE_2D, 0, 3, ix, iy, 0, GL_RGBA, GL_UNSIGNED_BYTE, image)
        # return the ID for use
        return ID

if __name__ == '__main__':
    app = wx.PySimpleApp(0)
    #wx.InitAllImageHandlers()
    frame = wx.Frame(None, -1, "Dragon Ilusion", size=(400,400))
    app.SetTopWindow(frame)
    canvas = DICanvas(frame)
    frame.Show(True)
    app.MainLoop()

