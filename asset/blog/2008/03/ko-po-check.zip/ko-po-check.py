#!/usr/bin/env python
# -*- coding: utf-8 -*-

import sys
#reload(sys)
import locale
try:
    sys.setdefaultencoding(locale.getpreferredencoding())
except:
    #sys in win32 don't have setdefaultencoding
    pass

import os,getopt
basedir = os.path.dirname(sys.argv[0])
moduledir = os.path.realpath(basedir)#"@prefix@/share/ko-po-check"
checksdir = os.path.join(moduledir, "checks")#"@prefix@/share/ko-po-check/checks"
VERSION = "0.9.win32"#"@VERSION@"

# processing the command line options

try:
    options, args = getopt.getopt(sys.argv[1:], "",
                                  ['help', 'version', 'moduledir=', 'checksdir='])
except getopt.GetoptError, msg:
    print "%s: %s" % (os.path.basename(sys.argv[0]), msg)
    sys.exit(1)

option_help = 0
option_version = 0

for (opt, val) in options:
    if opt == '--help':
        option_help = 1
    elif opt == '--version':
        option_version = 1
    elif opt == '--moduledir':
        moduledir = val
    elif opt == '--checksdir':
        checksdir = val
    
if not args:
    fn = '-'


sys.path.append(os.path.join(moduledir,'KPC'))
import po,poparse

if (option_help):
    helpmsg = [
        u'Usage: ko-po-check [옵션]... [파일]...<',
        u'      --help                이 도움말을 보여주고 종료합니다',
        u'      --version             버전 정보를 표시하고 종료합니다',
        u'',
        u' 파일이 `-\'이거나 파일이 주어지지 않은 경우 표준 입력에서 읽습니다.' ]
    for l in helpmsg:
        print l
    sys.exit(1)

if (option_version):
    print (u'ko-po-check %s' % VERSION)
    sys.exit(0)
    
import glob

filenames = glob.glob(checksdir+"/*/*.py")
filters = {}
for filename in filenames:
    f = {}
    execfile(filename, f)
    filters[f['name']] = f

retval = 0
for fn in args:
    if fn == '-':
        fp = sys.stdin
    else:
        fp = open(fn)

    try:
        catalog = poparse.parse_file(fp)
    except poparse.ParseError, lineno:
        print (u'%s:%d: 파싱 오류'%(fn,lineno))
        sys.exit(1)
    if fn != '-':
        fp.close()

    import string,re

    for entry in catalog.entries:
        if (not entry.is_translated()):
            continue
        for filtername in filters.keys():
            t,e = filters[filtername]['check'](entry.msgid, entry.msgstr)
            if not t:
                retval = 1
                for line in string.split(e,'\n'):
                    print (u'%s:%d: %s'%(fn,entry.msgstr_lineno,line))

sys.exit(retval)

# Local Variables:
# coding: utf-8
# End:
