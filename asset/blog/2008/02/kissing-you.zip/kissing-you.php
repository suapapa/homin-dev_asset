<?php
/*
Plugin Name: 키싱유-소녀시대 
Plugin URI: http://web.suapapa.net:8080/wordpress/?p=57 
Description: 그냥 플러그인이 아닙니다. 이것은 전 인류를 소시당으로 만들고자 하는 염원과 희망을 담고 있습니다. 이 플러그인을 활성화 하면 당신의 블로그 관리 페이지 우상단에 소녀시대의 '키싱유'의 가사 중 한 줄이 표시됩니다.
Author: Homin Lee
Version: 1.1
Author URI: http://www.suapapa.net/
*/

// These are the lyrics to Kissing You
$lyrics = "(All)뚜뚜루뚜뚜뚜~ Kissing you baby~ 뚜뚜루뚜뚜뚜~ Loving you baby~
(서현)장난스런 너의 키스에 기분이 좋아
(윤아)귀엽게 새침한 표정 지어도
(태연)어느샌가 나는 숙녀처럼~ 내 입술은 살근살근 그대이름 부르죠
(All)그대와 발을 맞추며 걷고 너의 두손을 잡고~ 니 어깨에 기대어 말하고 싶어
(써니)고마워 사랑해 행복만 줄께요~ Kissing you oh my love~
(All)내일은 따스한 햇살속에 너는 내옆에 누워~ 사랑의 노랠불러주며 웃어줘
(유리)달콤한 사랑의 기분좋은 한마디
(All)뚜뚜루뚜뚜뚜~ baby~ 뚜뚜루뚜뚜뚜~ Loving you baby~
(티파니)눈을 감고 너의 입술에 키스를 하며
(효연)내 볼은 핑크빛 물이 들어도
(제시카)내마음은 이미 넘어가고~ 내가슴에 두근대는 심장소리 들리죠
(All)그대와 발을 맞추며 걷고 너의 두손을 잡고~ 니 어깨에 기대어 말하고 싶어
(서현)고마워 사랑해 행복만 줄께요~ Kissing you oh my love
(All)내일은 따스한 햇살속에 너는 내 옆에 누워~ 사랑의 노랠불러주며 웃어줘
(수영)달콤한 사랑의 기분좋은 한마디
(써니)사랑해 사랑해 너만을 사랑해 하늘만큼
(태연)언제나 행복하게 환한 웃음줄께
(제시카)너만의 소중한 여자친구 약속해
(서현)너는 내옆에 있고 나의 두눈에 있고 너의 품안엔 항상 내가 있을께
(제시카)내가 있을께~
(All)그대와 발을 맞추며 걷고 너의 두손을 잡고 니 어깨에 기대어 말하고 싶어
(태연)고마워 사랑해 행복만 줄께요 Kissing you oh my love
(All)내일은 따스한 햇살속에 너는 내옆에 누워~ 사랑의노랠불러주며 웃어줘
(티파니)달콤한 사랑의 기분좋은 한마디
(제시카)달콤한 사랑의 기분좋은~ 사랑의 한마디";

// Here we split it into lines
$lyrics = explode("\n", $lyrics);
// And then randomly choose a line
$chosen = wptexturize( $lyrics[ mt_rand(0, count($lyrics) - 1) ] );

// This just echoes the chosen line, we'll position it later
function hello_kissingyou() {
	global $chosen;
	echo "<p id='kissingyou'>$chosen</p>";
}

// Now we set that function up to execute when the admin_footer action is called
add_action('admin_footer', 'hello_kissingyou');

// We need some CSS to position the paragraph
function kissingyou_css() {
	echo "
	<style type='text/css'>
	#kissingyou {
		position: absolute;
		top: 2.3em;
margin: 0; padding: 0;
		right: 1em;
		font-size: 16px;
		color: #f1f1f1;
	}
	</style>
	";
}

add_action('admin_head', 'kissingyou_css');

?>
