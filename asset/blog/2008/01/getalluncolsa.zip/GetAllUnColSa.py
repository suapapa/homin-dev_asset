#!/usr/bin/env python
# -*- coding: utf-8 -*-

if __name__ == '__main__':
    import os
    import re
    import time


    uncolsaAddr = 'http://couple.haruschool.com/dc/dc2.php?page=%d&id=eungolsa'

    imgCnt = 1
    pageNo = 1

    startTime = time.time()

    print "은꼴사 싹쓸이를 시작한다능. 하악하악"

    while(True):
        imgCntPerPage = 0
        os.system('wget -q -O temp.html "%s"'%(uncolsaAddr%pageNo))
        for line in open('temp.html'):
            imgs = re.findall(r'<img src=(.*?)>', line)
            if not imgs:
                continue
            else:
                for imgAddr in imgs:
                    os.system('wget -q -O uncol_%04d.jpg %s'%(imgCnt, imgAddr))
                    imgCnt += 1
                    imgCntPerPage += 1
        if imgCntPerPage == 0:
            break;
                
        pageNo += 1

    os.remove('temp.html')
    endTime = time.time()
    print '%d초 동안 %d개의 페이지에서 %d개의 이미지를 다운 받았다능. 하악하악.'%((endTime-startTime),pageNo,imgCnt-1)
